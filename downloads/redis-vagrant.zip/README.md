A simple vagrant configuration to create a box running redis. More [here](http://jasonpunyon.com/blog/2013/01/28/get-your-redis-on-on-windows/)

## Instructions


0. Install Vagrant (http://docs.vagrantup.com/v1/docs/getting-started/index.html)
1. Clone the repo.
2. cd to that directory.
3. vagrant up.
4. Enjoy a tasty beverage. You've earned it.

## License

Just don't sue me or cause someone else to want to sue me, OK?